# VAMPIRE KILLER MSX PLUS

MSX2版『悪魔城ドラキュラ』の操作と画面端処理を改善するIPSパッチです。

**3種類とも適用後のROMは1Mbit（128 KiB／131,072バイト）です。** 画像・音楽・ステージを削除せず、データの可逆圧縮と重複整理で元の容量内へ収めています。

| パッチ | 内容 |
|---|---|
| [fall_attack.ips](dist/fall_attack.ips) | 足場から落下している間も鞭・剣・斧・十字架・聖水・砂時計を使用可能にする |
| [screen_edges.ips](dist/screen_edges.ips) | 敵の端出現、小ハートの端消失、剣と直進する敵弾の端消失を改善する |
| [combined.ips](dist/combined.ips) | 上の2系統を両方適用する |

**斧と十字架が画面端で反転して戻る動作は維持します。**

## 画面端からの出現例

![左端から出現し、体の一部だけが見えているゾンビ](docs/images/zombie-left-edge.png)

`combined.ips` 適用版を電源投入から通常のキー入力で動かし、ゾンビが左端から入ってくる瞬間を撮影しました。画像はopenMSXの未加工スクリーンショットです。

## 適用方法

1. 手元の無改変ROMのサイズとSHA-256を確認してください。
2. 3つのうち**どれか1つ**のIPSを、無改変ROMのコピーへ適用してください。パッチを重ねる場合は `combined.ips` を使います。
3. 適用後のROMは元と同じ128 KiBです。エミュレーターでマッパーの指定が必要な場合は **Konami／SCCなし** を選んでください。従来の拡張版を使っていた場合も、無改変の原ROMへあらためて適用してください。

対応する入力は、日本版128 KiB、SHA-256が次のものです。

```text
99eabaaeb2b6c02220e131043d5a6401d0d8c5f413d89204547adcc04d65e7e2
```

IPS自体には入力ROMを識別する仕組みがありません。別版や改変済みROMへ適用しないでください。原ROMと適用済みROMは配布物に含めません。

## 変更の範囲

- 落下攻撃は、歩いて足場を外れた状態の攻撃進行・表示・特殊武器入力を変更します。落下速度、座標の小数、接地判定、着地音は維持します。発射待ちの剣の枠を聖水が上書きする組み合わせも防ぎます。
- 周期出現するゾンビ・コウモリなどの出現座標を左右端へ移します。ゾンビの出現先に床がない場合は元の座標へ戻します。プレイヤーの近くへの出現を避ける条件や出現周期は維持します。全種類の敵や退場条件を一括変更するものではありません。
- 小ハートは横座標を画面内へ制限し、横方向の端判定だけで消去しないようにします。着地時も拾得用の画像を画面内に収めます。揺れ・縦の動き・取得効果・着地後の寿命は変更しません。
- 剣と直進する敵弾は、最後のスプライトが画面外へ出るまで表示を続けます。画面をまたぐ座標の折り返しを識別し、反対側への表示・当たり判定を防ぎます。敵弾の対象は内部種別 `01/02/03/05/0A/0B` です。追尾弾や敵の戻る斧などの専用処理は対象外です。

## 検証

openMSX 21.0／C-BIOS MSX2 JPで、原版と3つの改良版をそれぞれ1,653条件・8,875回の関数終了で確認しました。入力RAMとレジスターを設定する関数診断です。移動と着地、BCDハートの消費、武器の枠管理、敵の生成、左右端の描画と消去、小ハートの着地、剣の誤判定、斧・十字架の反転と回収を含みます。

別途、各改良版を電源投入から通常のキー入力だけで63.5秒動かし、屋外3画面と城内3画面を通過しました。全編クリア、全機種、実機での動作は未確認です。結果とROMのハッシュは [検証記録](dist/verification.json) に保存しています。

1Mbit化では、全168ポーズの位置・パターン・色を原版と照合し、初期条件を揃えたアイテム・燭台の読み込み後のVRAM全128 KiBも一致しました。12画像の1,536バイトは932バイトへ可逆圧縮しています。従来の拡張版との比較でも、各版8,875回の観測でゲーム状態と表示用データが一致しました。[容量と画像の検証記録](dist/compact-verification.json)を参照してください。

## ビルドと再検証

Python 3の標準ライブラリーだけでパッチを生成できます。

```powershell
python tools/build_patches.py path/to/original.rom
python tools/verify_patch_files.py path/to/original.rom
```

`dist/` にIPSとハッシュ一覧、`build/` に適用済みROMとコードの一覧を生成します。ビルダーは入力ROMのハッシュが異なる場合に停止します。

エミュレーターの診断を再実行する場合は、openMSXのポータブル版を用意してください。

```powershell
python tools/verify_emulator.py path/to/original.rom --openmsx path/to/openmsx.exe
python tools/verify_compact_rom.py path/to/original.rom --openmsx path/to/openmsx.exe
```

出現例のスクリーンショットも通常操作から再撮影できます。

```powershell
python tools/capture_edge_screenshot.py --rom build/combined.rom --openmsx path/to/openmsx.exe
```

撮影画像は `build/screenshot/` に保存します。掲載画像は `zombie-left-01.png` です。

実装は [tools/patches.py](tools/patches.py)、可逆圧縮と表示データの整理は [tools/compact_assets.py](tools/compact_assets.py) にあります。追加コードは原ROMのバンク6内へ収め、起動時にRAM `$E618–E7FF` と `$F100–F1C8` 内へ配置します。両機能版の追加コードは647バイトで、再配置したROM領域には149バイトの余裕があります。通常の更新中に追加コード用のバンク切替は行いません。

RAMの利用範囲は、[MSX2 Technical Handbookのカートリッジ作業領域の説明](https://konamiman.github.io/MSX2-Technical-Handbook/md/Chapter5b.html)と、原作のスタック・変数・画像バッファの配置を確認して選んでいます。
