"""Screen-edge behavior: resident helpers and original-ROM hooks."""
import struct

from fixes import Explanation, Fix


def emit_helpers(c):
    c.labels["spawn_original"] = 0x5F1D
    c.label("main_actor")
    c.emit("E5 DD E5 E1 7C E1 FE D7 C9", "compare IX record page with $D7, preserving HL")
    c.label("linear_bullet")
    c.emit("E5 DD E5 E1 7C E1 FE D7", "push hl / push ix / pop hl / ld a,h / pop hl / cp $D7")
    c.jr("not_linear", "c")
    c.emit("DD 7E 00 3D FE 03", "ld a,(ix+0) / dec a / cp 3")
    c.jr("is_linear", "c")
    c.emit("FE 04", "cp 4 ; type 5")
    c.jr("is_linear", "z")
    c.emit("D6 09 FE 02", "sub 9 / cp 2 ; types 10,11")
    c.jr("is_linear", "c")
    c.label("not_linear")
    c.emit("3E 01 B7 C9", "ld a,1 / or a / ret")
    c.label("is_linear")
    c.emit("AF C9", "xor a / ret")
    c.label("projectile_init")
    c.emit("DD 36 7D 00 DD 36 7F 01 C9", "ld (ix+$7D),0 / ld (ix+$7F),1 / ret")
    c.label("spawn_ground")
    c.emit("D5 C5", "push de / push bc")
    c.call("edge_coordinate")
    c.emit("D5", "push de")
    c.call(0x7D2F)
    c.call(0x7C5E)
    c.emit("D1 C1", "pop de / pop bc")
    c.jr("ground_supported", "c")
    c.emit("D1", "pop de ; retain original position when edge has no floor")
    c.jp("spawn_original")
    c.label("ground_supported")
    c.emit("E1", "pop hl ; discard saved original DE")
    c.jp("spawn_original")
    c.label("spawn_flying")
    c.call("edge_coordinate")
    c.jp("spawn_original")
    c.label("edge_coordinate")
    c.emit("7A FE 80 16 00", "ld a,d / cp $80 / ld d,0")
    c.emit("D8 15 C9", "ret c / dec d / ret ; right edge = 255")

    c.label("cull_x")
    c.call("linear_bullet")
    c.jr("bullet_cull", "z")
    c.call("main_actor")
    c.jr("original_cull", "nc")
    c.emit("DD 7E 00 FE 24 C8", "ld a,(ix+0) / cp $24 / ret z ; keep small hearts")
    for kind in (1, 4, 7, 8):
        c.emit(f"FE {kind:02X}", f"cp ${kind:02X}")
        c.jr("enemy_cull", "z")
    c.label("original_cull")
    c.emit("DD 7E 05", "ld a,(ix+5)")
    c.jp(0x99EF)
    c.label("enemy_cull")
    c.emit("DD 7E 05 FE 07", "ld a,(ix+5) / cp 7")
    c.jr("enemy_right", "nc")
    c.emit("DD CB 0A 7E C8", "bit 7,(ix+10) / ret z ; entering from left")
    c.jp(0x99F6)

    c.label("bullet_cull")
    c.emit("DD 7E 7D B7 C8 DD 7E 05", "ld a,(ix+$7D) / or a / ret z / ld a,(ix+5)")
    c.emit("DD CB 0A 7E", "bit 7,(ix+10)")
    c.jr("bullet_left", "nz")
    c.emit("FE 08 D8", "cp 8 / ret c")
    c.jp(0x99F6)
    c.label("bullet_left")
    c.emit("FE F9 D0", "cp $F9 / ret nc")
    c.jp(0x99F6)
    c.label("enemy_right")
    c.emit("FE F1 D8 DD CB 0A 7E C0", "cp $F1 / ret c / bit 7,(ix+10) / ret nz")
    c.jp(0x99F6)

    # Both normal and shared pose tables call this with A = part X offset.
    # Signed offsets vary by pose; preserve each part's actual coordinates.
    c.label("sprite_x")
    c.emit("C5 4F DD 7E 00", "push bc / ld c,a / ld a,(ix+0)")
    c.call("linear_bullet")
    c.jr("sprite_selected", "z")
    c.call("main_actor")
    c.jr("sprite_original", "nc")
    c.emit("DD 7E 00", "ld a,(ix+0)")
    for kind in (1, 4, 7, 8, 0x24):
        c.emit(f"FE {kind:02X}", f"cp ${kind:02X}")
        c.jr("sprite_selected", "z")
    c.label("sprite_original")
    c.emit("79 C1 DD 86 05 C9", "ld a,c / pop bc / add a,(ix+5) / ret")
    c.label("sprite_selected")
    c.emit("E5 2C 2C CB BE", "push hl / inc l / inc l / res 7,(hl)")
    c.call("linear_bullet")
    c.jr("sprite_screen", "nz")
    c.emit("DD 7E 7D B7", "ld a,(ix+$7D) / or a")
    c.jr("sprite_screen", "z")
    c.emit("79 DD 86 05 DD CB 0A 7E", "ld a,c / add a,(ix+5) / bit 7,(ix+10)")
    c.jr("sprite_wrapped_left", "nz")
    c.emit("CB 79", "bit 7,c")
    c.jr("sprite_hide", "z")
    c.jr("sprite_hide", "c")
    c.jr("sprite_done")
    c.label("sprite_wrapped_left")
    c.emit("CB 79", "bit 7,c")
    c.jr("sprite_early", "nz")
    c.jr("sprite_done", "c")
    c.jr("sprite_early")
    c.label("sprite_screen")
    c.emit("CB 79", "bit 7,c ; signed part offset")
    c.jr("sprite_positive", "z")
    c.emit("79 DD 86 05", "ld a,c / add a,(ix+5)")
    c.jr("sprite_done", "c")
    c.jr("sprite_early")
    c.label("sprite_positive")
    c.emit("79 DD 86 05", "ld a,c / add a,(ix+5)")
    c.jr("sprite_done", "nc")
    c.label("sprite_hide")
    c.emit("2D 2D 2D 36 E0 2C 2C 2C", "hide the part Y when its left edge is beyond 255")
    c.jr("sprite_done")
    c.label("sprite_early")
    c.emit("C6 20 CB FE", "add a,32 / set 7,(hl) ; VDP early clock")
    c.label("sprite_done")
    c.emit("E1 C1 C9", "pop hl / pop bc / ret")
    c.label("sprite_shared")
    c.emit("D9", "exx ; access the part record, not the shared ROM coordinates")
    c.call("sprite_x")
    c.emit("D9 C9", "exx / ret")

    c.label("integrate_x")
    c.call("linear_bullet")
    c.jr("bullet_integrate", "z")
    c.emit("DD 7E 00 FE 24", "ld a,(ix+0) / cp $24")
    c.jr("integrate_original", "nz")
    c.emit("CB 7A", "bit 7,d ; signed X velocity")
    c.jr("heart_left", "nz")
    c.emit("19", "add hl,de")
    c.jr("heart_right_limit", "c")
    c.label("heart_bounds")
    c.emit("7C FE F8", "ld a,h / cp $F8")
    c.jr("heart_store", "c")
    c.label("heart_right_limit")
    c.emit("21 00 F8", "ld hl,$F800")
    c.jr("heart_store")
    c.label("heart_left")
    c.emit("19", "add hl,de")
    c.jr("heart_bounds", "c")
    c.emit("21 00 00", "ld hl,0")
    c.jr("heart_store")
    c.label("integrate_original")
    c.emit("19", "add hl,de")
    c.label("heart_store")
    c.emit("DD 75 04 DD 74 05 C9", "ld (ix+4),l / ld (ix+5),h / ret")
    c.label("bullet_integrate")
    c.emit("CB 7A", "bit 7,d")
    c.jr("bullet_integrate_left", "nz")
    c.emit("19", "add hl,de")
    c.jr("heart_store", "nc")
    c.jr("bullet_wrapped")
    c.label("bullet_integrate_left")
    c.emit("19", "add hl,de")
    c.jr("heart_store", "c")
    c.label("bullet_wrapped")
    c.emit("DD 36 7D 01 DD 36 0E 00", "ld (ix+$7D),1 / ld (ix+14),0 ; suppress wrapped collisions")
    c.jr("heart_store")

    c.label("heart_landing_x")
    c.emit("7C FE 04 DD 7E 05 C0 FE F0 D8 3E F0 C9",
           "ld a,h / cp 4 / ld a,(ix+5) / ret nz / cp $F0 / ret c / ld a,$F0 / ret")
    c.label("drop_floor")
    c.emit("DD 7E 00 FE 24", "ld a,(ix+0) / cp $24")
    c.branch(0xC2, 0x7B98, "jp nz,")
    c.call(0x7D2F)
    c.call(0x7C5E)
    c.emit("D8 7A D6 0A", "ret c / ld a,d / sub 10")
    c.jr("drop_second_probe", "nc")
    c.emit("B7 C9", "or a / ret ; no wrapped floor probe")
    c.label("drop_second_probe")
    c.emit("57", "ld d,a")
    c.call(0x7D2F)
    c.jp(0x7C5E)

    c.org(0xF100)
    c.label("weapon_x")
    c.emit("DD 7E 01 FE 02", "ld a,(ix+1) / cp 2")
    c.jr("weapon_move_original", "nz")
    c.emit("DD CB 03 7E DD 7E 05", "bit 7,(ix+3) / ld a,(ix+5)")
    c.jr("weapon_move_left", "nz")
    c.emit("DD 86 03 D0", "add a,(ix+3) / ret nc")
    c.jr("weapon_wrapped")
    c.label("weapon_move_left")
    c.emit("DD 86 03 D8", "add a,(ix+3) / ret c")
    c.label("weapon_wrapped")
    c.emit("DD 36 0F 01 C9", "ld (ix+15),1 / ret")
    c.label("weapon_move_original")
    c.emit("DD 7E 05 DD 86 03 C9", "ld a,(ix+5) / add a,(ix+3) / ret")
    c.label("weapon_cull")
    c.emit("DD 7E 01 FE 02", "ld a,(ix+1) / cp 2")
    c.jr("weapon_cull_original", "nz")
    c.emit("DD 7E 0F B7 C8 DD 7E 05 DD CB 03 7E", "ld a,(ix+15) / or a / ret z / ld a,(ix+5) / bit 7,(ix+3)")
    c.jr("weapon_cull_left", "nz")
    c.emit("FE 08 D8", "cp 8 / ret c")
    c.jp(0x74E9)
    c.label("weapon_cull_left")
    c.emit("FE F9 D0", "cp $F9 / ret nc")
    c.jp(0x74E9)
    c.label("weapon_cull_original")
    c.emit("DD 7E 05", "ld a,(ix+5)")
    c.jp(0x74DA)
    c.label("weapon_draw")
    c.call(0x7535)
    c.emit("DD 7E 01 FE 02 C0 DD 7E 0F B7", "ld a,(ix+1) / cp 2 / ret nz / ld a,(ix+15) / or a")
    c.jr("weapon_draw_screen", "z")
    c.emit("DD CB 03 7E C8", "bit 7,(ix+3) / ret z")
    c.jr("weapon_early")
    c.label("weapon_draw_screen")
    c.emit("DD 7E 05 FE 08 D0", "ld a,(ix+5) / cp 8 / ret nc")
    c.label("weapon_early")
    c.emit("DD E5 E1 7D FE 50 21 19 D6 11 60 D4", "push ix / pop hl / ld a,l / cp $50 / ld hl,$D619 / ld de,$D460")
    c.jr("weapon_early_slots", "z")
    c.emit("21 21 D6 11 80 D4", "ld hl,$D621 / ld de,$D480")
    c.label("weapon_early_slots")
    c.emit("7E C6 20 77 2C 2C 2C 2C 7E C6 20 77 EB 06 20", "add 32 to both SAT X values / ex de,hl / ld b,32")
    c.label("weapon_color")
    c.emit("CB FE 23", "set 7,(hl) / inc hl")
    c.branch(0x10, "weapon_color", "djnz", True)
    c.emit("C9", "ret")
    # The rectangle dispatcher reads IY+15 before using a sword position.
    c.label("weapon_collision")
    c.emit("3E 06 85 6F", "ld a,6 / add a,l / ld l,a")
    c.emit("FD 7E 01 FE 02", "ld a,(iy+1) / cp 2")
    c.jr("weapon_collision_original", "nz")
    c.emit("FD 7E 0F B7 C0", "ld a,(iy+15) / or a / ret nz ; carry clear")
    c.label("weapon_collision_original")
    c.jp(0x8504)


def apply(edit, hook, c):
    hook(0x5CF9, "C3 1D 5F", "spawn_ground", "Spawn zombies at an edge with physical floor", 0xC3)
    hook(0x5DB8, "C3 1D 5F", "spawn_flying", "Spawn periodic flying enemies at X=0/255", 0xC3)
    hook(0x59EC, "DD 7E 05", "cull_x", "Keep entering enemies and small hearts", 0xC3)
    hook(0x247E, "DD 86 05", "sprite_x", "Clip normal pose parts with early clock")
    hook(0x24B4, "DD 86 05", "sprite_shared", "Clip shared pose parts with early clock")
    integrate = b"\xc3" + struct.pack("<H", c.labels["integrate_x"]) + b"\x00" * 5
    edit(0x59DD, "19 DD 75 04 DD 74 05 C9", integrate, "Clamp small-heart X integration without wrapping")
    hook(0x5C12, "DD 7E 05", "heart_landing_x", "Keep resting small-heart sprites inside the screen")
    hook(0x5C63, "C3 98 7B", "drop_floor", "Prevent small hearts from probing the opposite edge", 0xC3)
    edit(0x5FB2, "DD 36 7F 01", b"\xcd" + struct.pack("<H", c.labels["projectile_init"]) + b"\0", "Reset linear projectile edge state")
    hook(0x34C7, "DD 86 03", "weapon_x", "Track sword X overflow")
    hook(0x34D7, "DD 7E 05", "weapon_cull", "Keep swords until all pixels leave the screen", 0xC3)
    hook(0x32CB, "C3 35 75", "weapon_draw", "Clip sword sprites; preserve other weapon drawing", 0xC3)
    hook(0x4500, "3E 06 85", "weapon_collision", "Reject sword collisions after X wraps", 0xC3)


FIX = Fix(
    id='screen_edges',
    title_ja='画面端の処理', title_en='Screen-edge behavior',
    description_ja='敵の端出現と、小ハート・剣・直進する敵弾の端消失を改善します。',
    description_en='Improve enemy entry and the edges for small hearts, swords, and straight-moving enemy projectiles.',
    emit_helpers=emit_helpers, apply=apply,
    behavior_change=True,
    explanation=Explanation(
        symptom_ja=("周期的に現れるゾンビやコウモリなどが、画面の端より内側に突然現れます。"
                    "小ハートは左右へ揺れて画面端へ達すると、その判定だけで消えることがあります。"
                    "剣と一部の直進する敵弾も、絵がまだ画面内に残っている段階で消えます。"
                    "この項目は、これらの出現と消失を画面端で自然に見せるための挙動改善です。"),
        symptom_en=("Periodically spawned zombies, bats, and similar enemies can appear suddenly inside the screen. "
                    "A small heart can disappear just because its horizontal sway reaches an edge. Swords and some "
                    "straight-moving enemy projectiles also disappear while part of their image is still visible. "
                    "This option changes those entry and exit behaviors at the screen edges."),
        trigger_ja=("周期出現する敵を待つ、小ハートが画面端へ揺れるまで待つ、"
                    "または剣・対象の敵弾が左右端へ進む場面で見られます。"),
        trigger_en=("Wait for a periodic enemy spawn, let a small heart sway to an edge, or let a sword or an affected "
                    "enemy projectile travel off either side of the screen."),
        correction_ja=("対象の敵は左右端から一部ずつ姿を現します。ゾンビの出現先に床がない場合は元の位置を使います。"
                       "小ハートは横方向を画面内へ収め、画面端だけを理由に消えません。剣と対象の敵弾は絵が全部"
                       "画面外へ出るまで表示し、反対側へ出現したり当たったりしないようにします。"),
        correction_en=("Affected enemies enter gradually from the edges. Zombies keep their original spawn position if "
                       "the edge has no floor. Small hearts stay within the horizontal bounds instead of disappearing "
                       "at an edge. Swords and affected projectiles remain visible until the whole image is outside "
                       "and cannot wrap around to appear or collide on the opposite side."),
        notes_ja=("斧と十字架が端で反転して戻る動きは維持します。すべての敵や敵弾を一括変更するものではありません。"
                  "敵の出現間隔、小ハートの揺れ・取得効果・着地後の寿命も変えません。"),
        notes_en=("Axes and crosses still turn back at the edges. This does not change every enemy or projectile. "
                  "Spawn timing and small hearts' sway, pickup effects, and lifetime after landing are preserved."),
    ),
)
